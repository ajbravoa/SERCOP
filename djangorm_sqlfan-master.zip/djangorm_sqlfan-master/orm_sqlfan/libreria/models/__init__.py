from .autores import Autor
from .libros import Libro
from .editoriales import Editorial
from .libros_cronica import LibroCronica
from .autor_capitulo import AutorCapitulo
from .vlibros import VLibroautores
