# djangorm_sqlfan
Tutorial sobre el orm de django para fans de sql

Este es el repositorio de los ejemplos del tutorial Orm de django para fans de sql disponible en:
https://www.youtube.com/playlist?list=PLCyziqF_kz_jSfXLvKsTH5aakTyvRoZlu

Ademas ya se encuentra disponible la guia del mismo en espera de tus comentarios:
https://raw.githubusercontent.com/rulotr/djangorm_sqlfan/master/ORM%20para%20fans%20de%20SQL.pdf
